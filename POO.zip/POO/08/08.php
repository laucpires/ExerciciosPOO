<!-- 8. Implemente uma classe chamada “Carro” com atributos para armazenar a marca, o modelo e a velocidade atual do carro. 
Adicione métodos para acelerar, frear e exibir a velocidade atual. -->