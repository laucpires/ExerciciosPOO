<!-- 3. Crie uma classe chamada “Retângulo” que possua atributos para armazenar a largura e a altura. 
Implemente métodos para calcular a área e o perímetro do retângulo. -->