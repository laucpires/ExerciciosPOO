<!-- 7. Crie uma classe chamada “Triângulo” com atributos para armazenar os três lados do triângulo. 
Implemente métodos para verificar se é um triângulo válido e calcular sua área. -->